
check  {
Telegram Desktop - ✅
Telegram App - ✅
TG Servers - ❌
};
